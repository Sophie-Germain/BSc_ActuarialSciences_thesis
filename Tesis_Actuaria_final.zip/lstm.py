#MARIA FERNANDA MORA ALBA
#LSTM PARA PREDICCION DE SERIES DE TIEMPO
#24 NOVIEMBRE 2016

import numpy
import matplotlib.pyplot as plt
import pandas
import math
from keras.models import Sequential
from keras.layers import Dense
from keras.layers import LSTM
from keras.layers import Dropout
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import mean_squared_error
import os
os.chdir("/home/sophia/tesis_lic/tesis/tesis_final/final")
#os.chdir("/home/sophie/tesis/data/final_code")

#===============================================================
#===========================PREPROCESAMIENTO====================
#===============================================================

# Fijamos la semilla  para tener reproducibilidad
numpy.random.seed(103596)
# Cargando y explorando dataset original con datos no estacionarios

print('Graficamos la serie de tiempo: ')
dataframe_noest = pandas.read_csv('data_noest.csv', usecols=[0],
    engine='python')
plt.plot(dataframe_noest, color='#5e6d96')
plt.ylabel('Demanda sin transformar (MWs)')
plt.xlabel('Tiempo')
#plt.show()


#dataset = dataset.astype('float32')

# Hacemos los datos estacionarios en R e importamos el csv
print('Graficamos la serie de tiempo estacionaria: ')
dataframe = pandas.read_csv('data_est.csv', usecols=[0], 
    engine='python')
plt.plot(dataframe, color='#5e6d96')
plt.ylabel('Demanda estacionaria')
plt.xlabel('Tiempo')
#plt.show()
# guardamos los valores solamente
dataset = dataframe.values

# escalamos el dataset a (0,1) para poder usar una red neuronal
# Usamos esta transformacion: X_std = (X - X.min(axis=0)) / 
# (X.max(axis=0) - X.min(axis=0)) como una alternativa a media cero 
# y varianza unitaria.
scaler = MinMaxScaler(feature_range=(0, 1))
#fit a los datos y luego los transformamos
dataset = scaler.fit_transform(dataset)

#visualizamos la serie de tiempo estacionaria y escalada, 
# con esta trabajaremos
print('Graficamos la serie de tiempo estacionaria y escalada en
    (0,1): ')
plt.plot(dataset, color='#5e6d96')
plt.ylabel('Demanda estacionaria y escalada en (0,1)')
plt.xlabel('Tiempo')
#plt.show()

print('Creamos dataset de entrenamiento y prueba... ')
# dividimos en entrenamiento y prueba. (to be refined for time 
# series prediction)
train_size = int(len(dataset) * 0.8)
#test_size = len(dataset) - train_size
train, test = dataset[0:train_size,:], 
    dataset[train_size:len(dataset),:]

# Reformular como X=t and Y=t+1
# hay que convertir el vector de valores de la serie de tiempo en 
# una matriz para poder aplicar algoritmos de prediccion
def create_dataset(dataset, lag=1):
    dataX, dataY = [], []
    for i in range(len(dataset)-lag-1):
        a = dataset[i:(i+lag), 0]
        dataX.append(a)
        dataY.append(dataset[i + lag, 0])
    return numpy.array(dataX), numpy.array(dataY)

#Cambiamos el tamano de la ventana
lag = 9
trainX, trainY = create_dataset(train, lag)
testX, testY = create_dataset(test, lag)

# Actualmente los datos estan en la forma de [samples, features]
# Reformular el input para que sea [samples, time steps, features]
trainX = numpy.reshape(trainX, (trainX.shape[0], trainX.shape[1], 1))
testX = numpy.reshape(testX, (testX.shape[0], testX.shape[1], 1))

#====================================================================
#===============================MODELO===============================
#====================================================================
# Creacion y entrenamiento de la LSTM network
# La red tiene una capa visible con 1 input y el output debe ser 1 
# valor (la prediccion)
# Los parametros de la red son:
#    - Tamano del lag
#    - Numero de bloques
#    - Profundidad
#    - Dropout
#    - Tamano del batch
#    - Numero de epocas
#    - Funcion de activacion

print('Creando arquitectura LSTM... ')
batch_size = 1
model = Sequential()

#lag=input_length, input_dim=1
##Stateful=true porque queremos memoria entre batches
model.add(LSTM(6, batch_input_shape=(batch_size, lag, 1), 
    stateful=True, return_sequences=False ))
#model.add(Dropout(0.8))
#model.add(LSTM(6, return_sequences=True, stateful=True ))
#model.add(Dropout(0.5))
#model.add(LSTM(6, return_sequences=True, stateful=True ))
#model.add(LSTM(6, return_sequences=True), stateful=True)
#model.add(Dropout(0.5))
#model.add(LSTM(6, return_sequences=True, stateful=True ))
#model.add(LSTM(6, return_sequences=True), stateful=True)
#model.add(Dropout(0.5))
#model.add(LSTM(6, return_sequences=False, stateful=True))
#model.add(Dropout(0.5))

#output layers. Size=1 (1 timestep)
model.add(Dense(1))
model.compile(loss='mean_squared_error', optimizer='adam')
print('Entrenando modelo... ')

#Stateful=True, hay que resetear el estado en cada epoca 
for i in range(200):
    model.fit(trainX, trainY, nb_epoch=1, batch_size=batch_size, 
        verbose=2, shuffle=False)
    model.reset_states()
    
#Stateful=False
#model.fit(trainX, trainY, nb_epoch=100, batch_size=1, verbose=2)

print('El numero de parametros en cada capa es: ')
model.summary()

#=============================================================
#============================EVALUACION=======================
#=============================================================
# Predicciones
#print('Haciendo predicciones: ')Pre
trainPredict = model.predict(trainX, batch_size=batch_size)
model.reset_states()
testPredict = model.predict(testX, batch_size=batch_size)
# Invertimos predicciones a sus unidades originales
print('Desescalando los datos... ')
trainPredict = scaler.inverse_transform(trainPredict)
trainY = scaler.inverse_transform([trainY])
testPredict = scaler.inverse_transform(testPredict)
testY = scaler.inverse_transform([testY])
# Calculamos el RMSE

print('Evaluando modelo en entrenamiento y prueba: ')
trainScore = math.sqrt(mean_squared_error(trainY[0], 
    trainPredict[:,0]))
print('Train Score: %.5f RMSE' % (trainScore))
testScore = math.sqrt(mean_squared_error(testY[0], 
    testPredict[:,0]))
print('Test Score: %.5f RMSE' % (testScore))

#==============================================================
#============================VISUALIZACION=====================
#==============================================================
print('Graficando datos originales y estimados por el modelo: ')
# Shift predicciones de train para graficarlas
trainPredictPlot = numpy.empty_like(dataset)
trainPredictPlot[:, :] = numpy.nan
trainPredictPlot[lag:len(trainPredict)+lag, :] = trainPredict
# Shift predicciones de test para graficarlas
testPredictPlot = numpy.empty_like(dataset)
testPredictPlot[:, :] = numpy.nan
testPredictPlot[len(trainPredict)+(lag*2)+1:len(dataset)-1, :] 
    = testPredict
# Graficamos reales y predicciones
plt.plot(scaler.inverse_transform(dataset))
#dataset=np.exp(dataset)
plt.plot(trainPredictPlot)
plt.plot(testPredictPlot)
plt.show()

#Ahora regresamos a las unidades originales de la base de datos y 
#graficamos. Para esto hay que aplicar exponencial para quitar la 
#transformacion logaritmo que estabilizaba la varianza de los datos
#(eso se hizo en R)